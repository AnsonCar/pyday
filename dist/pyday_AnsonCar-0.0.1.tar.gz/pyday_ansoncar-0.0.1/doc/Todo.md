pyday
- python library
- class oop magic method

- numpy padas sqlite3
- mapplotlib pyechat 

設計
- 跟python官方 開發庫方法
- For 泰迪杯比賽使用
- 快速使用，快速上手
- 一句call function，集成 功能
- 由處理數據 到 數據分析 到數據可視化
- 未來加入 機器學習
- 線性回歸
- 適配 jupyter
- 開源